## LG Development 
# V1 - First Version 
# DM Me for help: pro.gibor
# Join My Discord:
## LG-ITEMMAKER
About the script: Making item when clicking any button you choose
# Dependencies: 
- [qb-core](https://github.com/qbcore-framework/qb-core)
- [ox_lib](https://github.com/overextended/ox_lib)
- [ox_inventory](https://github.com/overextended/ox_inventory)
ox_inventory you can convert it to any other inventory but I will not help you if you need help
# Working With:
QB-Framwork Only! You can convert it to esx but I will not help you if you need help
# Things you need to change: 
You need to change things in addItemOnKeyPress.lua:
Line 2, Vector3 Of the point that you want to be able to click the button you choose
Line 33 Change the message to whatever you want
Line 40 Change the message to whatever you want
Line 48 Change 38 With whatever number you want -- 38 = E (The number you choose will be the button you need to click)
# In line 48 you only need to switch 38 and not the 1 example: do - (1, 38) don't do (38, 38)
----------------------------------------------
# Installation:
- Download the script
- Unzip the folder
- Move the folder to your resource folder
- Add in server.cfg: ensure lg-itemmaker
----------------------------------------------
# All Right Reserved to LG - LionGibor Development
# Thank you for choosing LG Developement!