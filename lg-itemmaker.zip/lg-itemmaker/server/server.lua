local QBCore = exports['qb-core']:GetCoreObject()

RegisterServerEvent('ox_inventory:addItem')
AddEventHandler('ox_inventory:addItem', function(itemName, itemCount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    if Player then
        exports.ox_inventory:AddItem(src, itemName, itemCount)
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Item',
            description = 'Item added to inventory!',
            type = 'success'
        })
    end
end)
