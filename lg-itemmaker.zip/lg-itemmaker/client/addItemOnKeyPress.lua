
local targetLocation = vector3(000, 000, 000) -- Replace with your desired coordinates
local proximityThreshold = 3.0 
local notified = false 


function drawText(text, x, y, scale, r, g, b, a)
    SetTextFont(0)
    SetTextProportional(1)
    SetTextScale(scale, scale)
    SetTextColour(r, g, b, a)
    SetTextEntry("STRING")
    AddTextComponentString(text)
    DrawText(x, y)
end


Citizen.CreateThread(function()
    
    while true do
        Citizen.Wait(0) 

        
        local playerPed = PlayerPedId()
        local playerPos = GetEntityCoords(playerPed)


        if #(playerPos - targetLocation) < proximityThreshold then
            if not notified then
                
                TriggerEvent('ox_lib:notify', {
                    title = 'Item',
                    description = 'Press E to get make ak47 weed', -- Replace with whatever you want
                    type = 'inform'
                })
                notified = true
            end


            drawText("Press ~g~E~s~ to make ak47 weed", 0.05, 0.05, 0.5, 255, 255, 255, 255) -- Replace With whatever you want, Switch E to the key you want to use

            -- Check if the 'E' key is pressed
            if IsControlJustPressed(1, 38) then -- 38 = E, You can change it to any key by getting his number
                -- Start progress bar
                local endTime = GetGameTimer() + 10000 -- 10 seconds progress

                while GetGameTimer() < endTime do
                    Citizen.Wait(0) 


                    local progress = (GetGameTimer() - (endTime - 10000)) / 10000
                    local x = 0.5
                    local y = 0.95
                    local w = 0.2
                    local h = 0.02

                    DrawRect(x, y, w, h, 0, 0, 0, 150) 
                    DrawRect(x, y, w * progress, h, 0, 255, 0, 200) 

                    
                    

                    
                    if IsControlJustPressed(1, 322) then
                        TriggerEvent('ox_lib:notify', {
                            title = 'Cancelled',
                            description = 'Item addition cancelled.',
                            type = 'error'
                        })
                        return
                    end
                end

                
                TriggerServerEvent('ox_inventory:addItem', 'item', 1) -- replace 'item' with you item name
                TriggerEvent('ox_lib:notify', {
                    title = 'Success',
                    description = 'Item added to inventory!',
                    type = 'success'
                })
            end
        else
            notified = false
        end
    end
end)
