fx_version 'cerulean'
game 'gta5'

client_script 'client/addItemOnKeyPress.lua'
server_script 'server/server.lua'

author 'LG Development'
description 'Making item by clicking button you choose!'
version '1.0.0'

dependencies {
    'ox_lib', 
    'qb-core',
    'ox_inventory'
}
